!   FILE for FullProf Studio: generated automatically by FullProf 
!Title: Cubic_K_FeMn_hexacyanoferrate                                                                                                                                       
SPACEG F m -3 m            
CELL    12.797740   12.797740   12.797740  90.0000  90.0000  90.0000   DISPLAY MULTIPLE
BOX   -0.15  1.15   -0.15  1.15    -0.15  1.15 
ATOM K1      K        0.25000   0.25000   0.25000  
ATOM FeC     Fe       0.00000   0.00000   0.00000  
ATOM FeN     Fe       0.50000   0.50000   0.50000  
ATOM MnN     Mn       0.50000   0.50000   0.50000  
ATOM C1      C        0.22354   0.00000   0.00000  
ATOM N1      N        0.30000   0.00000   0.00000  
