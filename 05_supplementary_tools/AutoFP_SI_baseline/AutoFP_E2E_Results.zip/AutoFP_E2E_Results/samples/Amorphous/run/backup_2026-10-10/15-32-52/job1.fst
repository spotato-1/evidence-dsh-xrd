!   FILE for FullProf Studio: generated automatically by FullProf 
!Title: Graphite_proxy_only                                                                                                                                                 
SPACEG P 63/m m c          
CELL     2.217757    2.217757    4.194844  90.0000  90.0000 120.0000   DISPLAY MULTIPLE
BOX   -0.15  1.15   -0.15  1.15    -0.15  1.15 
ATOM C1      C        0.00000   0.00000   0.25000  
ATOM C2      C        0.33333   0.66667   0.25000  
