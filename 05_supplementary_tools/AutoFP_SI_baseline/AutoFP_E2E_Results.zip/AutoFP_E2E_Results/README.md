# AutoFP 六样品固定结果包

这是 2026-10-10 执行的六样品单次 E2E 结果，每个样品仅启动一次 AutoFP。正式测试已经结束，本包用于阅读、审计及静态分析，不启动新增精修。

先打开 `AutoFP_E2E_Report.html`：它是含六张原生拟合图的自包含中文报告，不需要网络。`AutoFP_E2E_Report.md` 为同内容的可编辑文本版本，解压后图片相对路径有效。

## 目录

| 路径 | 内容 |
|---|---|
| `samples/<样品>/input/` | 启动前固定的 CIF、PCR、DAT、输入假设 JSON |
| `samples/<样品>/attempt_001.json` | 唯一调用的命令、时间、退出码、输入及原生结果 SHA-256 |
| `samples/<样品>/stdout_stderr.log` | 完整 CLI 标准输出和错误日志 |
| `samples/<样品>/run/` | 原生最终文件、参数轨迹、全部回滚和备份文件，保持原样 |
| `samples/<样品>/derived/` | 静态审查 JSON、冻结谱 TSV、未验证最终 CIF |
| `samples/<样品>/report.md` | 逐样品报告 |
| `original_inputs/` | 原始数据及上传的 FE50 候选 CIF |
| `sources/` | 使用的 COD 原始结构文件 |
| `provenance/` | 原提示词、模板、RAW 解码来源、环境预检日志 |
| `results.json`、`results.csv`、`verdicts.json` | 机器可读指标和判定 |
| `protocol.md`、`data_header_correction.json` | 测试协议及真实输入适配偏差 |
| `SOFTWARE.json` | 固定 CLI 版本、官方地址与 SHA-256 |
| `scripts/` | 准备、一次运行、冻结及静态分析、报告代码 |
| `SHA256SUMS.txt` | 包内所有文件的最终 SHA-256（清单自身除外） |

## 无引擎复核

在解压后的本目录运行 `python3 scripts/verify_frozen.py`，只进行字节校验，不调用 AutoFP 或 FullProf，不修改文件。也可在 Linux 上运行 `sha256sum -c SHA256SUMS.txt` 核验完整包。静态分析所用依赖见 `requirements_static.txt`；依赖就绪后，`python3 scripts/analyze_frozen.py` 可重新转写派生产物，同样不调用精修引擎。

`prepare_inputs_as_executed.py` 记录首次数据准备源代码；前三样品少读六点及后三样品首次运行前补头的实际差异详见协议。`prepare_inputs.py` 和 `run_once.py` 保留了防止覆盖/重复执行的检查，并使用此次环境的绝对路径；不要把它们当作可直接在本冻结目录重跑的入口。

原 CLI 已由用户提供，结果包不重复包含 108 MB 的可执行文件。报告所用的官方版本地址及哈希位于 `SOFTWARE.json`。所有 `unvalidated_final_phase_*.cif` 是保留异常参数的诊断转写，不是可直接发表的可靠结构；最终原生 PCR 和完整日志为审查依据。

六次调用均自然退出且无超时。前三样品各少读六点属于执行者的输入适配偏差；不归入 AutoFP 算法失败，也没有为此重跑。原生扣背景 Rwp 与全谱复算 Rwp 是不同口径。请连同报告的科学判断和局限使用本包，勿以退出码 0 或单一 R 值认定科学任务成功。
