"""Package already frozen results and an HTML report; never invoke an engine."""
from pathlib import Path
import base64
import hashlib
import html
from html.parser import HTMLParser
import json
import re
import shutil
import zipfile

BASE = Path(__file__).resolve().parents[1]
DELIVERY = BASE.parents[1] / 'deliverables'
DELIVERY.mkdir(exist_ok=True)

def digest(path):
    with path.open('rb') as handle:
        return hashlib.file_digest(handle, 'sha256').hexdigest()

def inline(text):
    value = html.escape(text)
    value = re.sub(r'`([^`]+)`', r'<code>\1</code>', value)
    value = re.sub(r'\*\*([^*]+)\*\*', r'<strong>\1</strong>', value)
    value = re.sub(r'https?://[^\s<,，；。]+', lambda m: '<a href="' + m[0] + '">' + m[0] + '</a>', value)
    return value

lines = (BASE / 'AutoFP_E2E_Report.md').read_text().splitlines()
blocks, headings, images = [], [], []
i = 0
while i < len(lines):
    line = lines[i]
    if not line.strip():
        i += 1
        continue
    if line.startswith('#'):
        level = len(line) - len(line.lstrip('#'))
        title = line[level:].strip()
        anchor = 'section-' + str(len(headings) + 1)
        headings.append((level, anchor, title))
        blocks.append(f'<h{level} id="{anchor}">{inline(title)}</h{level}>')
        i += 1
        continue
    match = re.fullmatch(r'!\[([^]]*)\]\(([^)]+)\)', line)
    if match:
        image_path = BASE / match[2]
        assert image_path.is_file() and image_path.suffix == '.png'
        encoded = base64.b64encode(image_path.read_bytes()).decode('ascii')
        images.append({'path': match[2], 'sha256': digest(image_path)})
        blocks.append('<figure><img alt="' + html.escape(match[1], quote=True) + '" src="data:image/png;base64,' + encoded + '"><figcaption>' + inline(match[1]) + ' · 原生拟合图，未修改</figcaption></figure>')
        i += 1
        continue
    if line.startswith('|'):
        rows = []
        while i < len(lines) and lines[i].startswith('|'):
            cells = [v.strip() for v in lines[i].strip().strip('|').split('|')]
            if not all(re.fullmatch(r':?-+:?', v) for v in cells):
                rows.append(cells)
            i += 1
        header = ''.join('<th>' + inline(v) + '</th>' for v in rows[0])
        body = ''.join('<tr>' + ''.join('<td>' + inline(v) + '</td>' for v in row) + '</tr>' for row in rows[1:])
        blocks.append('<div class="table-wrap"><table><thead><tr>' + header + '</tr></thead><tbody>' + body + '</tbody></table></div>')
        continue
    if line.startswith('- '):
        items = []
        while i < len(lines) and lines[i].startswith('- '):
            items.append('<li>' + inline(lines[i][2:]) + '</li>')
            i += 1
        blocks.append('<ul>' + ''.join(items) + '</ul>')
        continue
    paragraph = []
    while i < len(lines) and lines[i].strip() and not lines[i].startswith(('#', '|', '- ', '![')):
        paragraph.append(lines[i])
        i += 1
    blocks.append('<p>' + inline(' '.join(paragraph)) + '</p>')

assert len(images) == 6
toc = '<nav aria-label="目录">' + ''.join('<a href="#' + anchor + '">' + html.escape(title) + '</a>' for level, anchor, title in headings if level == 2) + '</nav>'
css = '''
* {box-sizing:border-box} html {scroll-behavior:smooth}
body {margin:0;background:#f4f6f9;color:#202b3a;font-family:system-ui,-apple-system,"Noto Sans CJK SC","Microsoft YaHei",sans-serif;font-size:16px;line-height:1.8}
main {max-width:1180px;margin:36px auto;padding:44px 52px;background:white;border:1px solid #dee5ee;border-radius:12px}
h1 {font-size:30px;line-height:1.4;color:#172b49;margin:0 0 20px} h2 {font-size:23px;color:#172b49;margin:42px 0 16px;padding-top:15px;border-top:1px solid #dce4ef;scroll-margin-top:20px}
p {margin:14px 0} strong {color:#9b351e} a {color:#17599a;overflow-wrap:anywhere} code {font-family:ui-monospace,monospace;background:#eef2f7;border-radius:4px;padding:1px 4px;font-size:.9em;overflow-wrap:anywhere}
nav {display:flex;flex-wrap:wrap;gap:7px 14px;background:#f0f4f8;padding:14px 18px;margin:25px 0;border-radius:7px;font-size:13px} nav a {text-decoration:none}
.table-wrap {overflow-x:auto;margin:18px 0} table {border-collapse:collapse;width:100%;font-size:14px;line-height:1.6} th {background:#eaf0f7;color:#172b49;text-align:left;font-weight:650} th,td {padding:10px 12px;border-bottom:1px solid #dce4ef;vertical-align:top} tr:nth-child(even) td {background:#f8fafc}
li {margin:5px 0;overflow-wrap:anywhere} figure {margin:24px 0 32px} img {display:block;max-width:100%;height:auto;border:1px solid #e0e6ee} figcaption {color:#65748a;font-size:13px;padding-top:8px}
footer {font-size:13px;color:#65748a;margin-top:35px;border-top:1px solid #dce4ef;padding-top:16px}
@media(max-width:760px) {main {margin:0;padding:24px 18px;border:0;border-radius:0} h1 {font-size:25px} h2 {font-size:21px}}
@media print {body {background:white;font-size:11pt} main {max-width:none;margin:0;padding:0;border:0} nav {display:none} h2 {break-after:avoid} table,figure {break-inside:avoid} a {color:inherit;text-decoration:none}}
'''
report_html = '<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>AutoFP 六样品一次 E2E 性能测试报告</title><style>' + css + '</style></head><body><main>' + toc + '\n'.join(blocks) + '<footer>本报告来自冻结原生结果；HTML 内嵌六张原生 PNG。完整命令、日志、输入和哈希见配套结果包。</footer></main></body></html>'
(BASE / 'AutoFP_E2E_Report.html').write_text(report_html)
(BASE / 'report_assets.json').write_text(json.dumps(images, indent=2, ensure_ascii=False))

class ReportInspector(HTMLParser):
    def __init__(self):
        super().__init__()
        self.imgs = []
        self.tables = 0
    def handle_starttag(self, tag, attrs):
        if tag == 'img':
            self.imgs.append(dict(attrs)['src'])
        if tag == 'table':
            self.tables += 1

inspection = ReportInspector()
inspection.feed(report_html)
assert len(inspection.imgs) == 6 and inspection.tables >= 9
for src, image_info in zip(inspection.imgs, images):
    assert hashlib.sha256(base64.b64decode(src.split(',', 1)[1])).hexdigest() == image_info['sha256']

import numpy
import gemmi
(BASE / 'requirements_static.txt').write_text(f'numpy=={numpy.__version__}\ngemmi=={gemmi.__version__}\n')
for extension in ['md', 'html']:
    filename = 'AutoFP_E2E_Report.' + extension
    shutil.copy2(BASE / filename, DELIVERY / filename)

manifest = BASE / 'SHA256SUMS.txt'
all_files = sorted(p for p in BASE.rglob('*') if p.is_file() and p != manifest)
assert not any(p.is_symlink() for p in all_files)
manifest.write_text(''.join(digest(p) + '  ' + str(p.relative_to(BASE)) + '\n' for p in all_files))
archive = DELIVERY / 'AutoFP_E2E_Results.zip'
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as output:
    for path in all_files + [manifest]:
        output.write(path, 'AutoFP_E2E_Results/' + str(path.relative_to(BASE)))
with zipfile.ZipFile(archive) as check:
    assert check.testzip() is None
    assert len(check.infolist()) == len(all_files) + 1
    for path in all_files:
        name = 'AutoFP_E2E_Results/' + str(path.relative_to(BASE))
        assert hashlib.sha256(check.read(name)).hexdigest() == digest(path), name
print(json.dumps({'archive_files': len(all_files) + 1, 'embedded_native_plots': len(images), 'report_tables': inspection.tables, 'deliverables': [{'path': str(p), 'bytes': p.stat().st_size, 'sha256': digest(p)} for p in sorted(DELIVERY.glob('AutoFP*'))]}, ensure_ascii=False, indent=2))
