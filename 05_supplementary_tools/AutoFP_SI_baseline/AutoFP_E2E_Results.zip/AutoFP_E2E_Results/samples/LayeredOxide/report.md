## LayeredOxide

本样品正式调用次数为 1，状态 `exited`，退出码 0，用时 1 分 54.5 秒。AutoFP 原生 Rwp 从 98.20% 变为 9.66%；冻结 PRF 全谱 Rwp 为 9.295%，PRF χ² 为 3.4916。

初始结构来源与适配：COD 4002260，Paulsen, Donaberger and Dahn, Chemistry of Materials 12 (2000) 2257–2267，P2 原型；按 Na₀.₇₂Ni₀.₃₃Mn₀.₆₂Mo₀.₀₅O₂ 投料比适配。Na₂MoO₄ 取 COD 2240655，Fortes, Acta Crystallographica E 71 (2015) 592–596，DOI 10.1107/S2056989015008774。

输入已包含 P2 型层状主相和 Na₂MoO₄ 候选；这来自测试执行者的检索和建模，并非 AutoFP 自动识相。主相 Mn/Ni/Mo 共用位点的总占位为 1.424，多个有效热参数为负；Na₂MoO₄ 的 a 从 9.10888 Å 缩至 6.52935 Å。尽管两种 Rwp 均小于 10%，这些结构异常仍使输出不能作为发表级结构或可靠相分数。最终质量比例只视作当前模型的数值参数。主相按投料比初始化，不能将它当作实测组成；本次未加入跨相 Mo 或 Na 质量守恒约束。

| 相 | 晶格参数 a b c / Å | Bov / Å² | 最低有效 Biso+Bov / Å² | 比例因子 |
|---|---|---:|---:|---:|
| P2_NaNiMnMoO2 | 2.88511 / 2.88511 / 11.14549 | -2.0931 | -7.1773 | 0.0006273153 |
| Na2MoO4 | 6.52935 / 6.52935 / 6.52935 | 0.0000 | 0.5843 | 0.0009757431 |

最终结构审查记录：

- phase1 negative raw Biso components (consider Bov gauge): O1
- phase1 negative effective Biso+Bov: Mn1=-1.593,O1=-7.177,Ni1=-1.593,Mo1=-1.593
- phase1 occupancy outside [0,1]: Mn1=1.044
- phase1 mixed site occupancy sum=1.424: Mn1,Ni1,Mo1

由最终 PCR 计算的模型质量比例为 1.26%, 98.74%。这些值继承最终占位/热参数的物理问题，不作有效定量相分数结论。

自动循环 3 次，日志中的参数尝试 309 次，已接受参数状态 134 项；回滚事件 175 次，奇异矩阵标记 14 次，PCR 转换错误 9 次，非有限数值错误标记 84 次。内部错误可由回滚恢复，不等于独立 E2E 失败次数。

轨迹中最低已接受原生 Rwp 为 9.66%；这是路径统计，没有用它替换最终 PCR 或再次精修。

末次 OUT 的 Ynet Rwp 与 CLI 最终总结一致；完整 OUT、PRF、PCR 和总结均保留。原生 PNG 图是否成功生成独立于数值拟合；CLI 的 EPS 导出出现缺少 backend_ps 的打包提示时，保留已有 PNG，不修改 CLI 包。

原生最终图如下，图中的 Rwp 标签采用 AutoFP 原生扣背景口径。

![LayeredOxide native fit](run/autofp_prf2fig_job.png)
