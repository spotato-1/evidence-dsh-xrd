!   FILE for FullProf Studio: generated automatically by FullProf 
!Title: Magnetite                                                                                                                                                           
SPACEG F d -3 m            
CELL     8.388872    8.388872    8.388872  90.0000  90.0000  90.0000   DISPLAY MULTIPLE
BOX   -0.15  1.15   -0.15  1.15    -0.15  1.15 
ATOM Fe1     Fe       0.12500   0.12500   0.12500  
ATOM Fe2     Fe       0.50000   0.50000   0.50000  
ATOM O       O        0.23872   0.23872   0.23872  
