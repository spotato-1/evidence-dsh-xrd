# AutoFP 六样品一次 E2E 性能测试报告

本批次已对上传的 6 个样品各启动一次 AutoFP，所有正式调用均已结束。没有外部重新启动、换模型重跑或追加精修。最终输入、原生输出、内部循环轨迹和失败证据均已保存。本文分别报告运行完成、数值拟合和科学产物三个层次；正常退出不等同于结构解析成功。

**本批次有明确的输入适配偏差。** 执行者最初遗漏了 FullProf Ins=10 数据文件要求的六行文件头，前三个已启动样品少读前 6 点。没有重跑；后三个在首次启动前补齐注释头，数值未改。该偏差不能计为 AutoFP 算法失败，也使本批次不能直接作为完全统一输入条件下的论文成功率基准。

## 测试版本与一次运行的定义

使用上传的 `autofp-cli`，108374496 字节，SHA-256 为 `3b4c25f882c275b67e98745e2f95e60a6f613d14730b789033b1e7d295cec740`，与官方 v1.7 beta15 发布资产一致。帮助文字 1.3.x 和包内配置 1.6.6 为旧版本标识。内置 FullProf v7.40 Jan2021，运行环境为 Ubuntu 24.04.3、包内 Python 3.9.13。使用默认专家系统 `-c 0 -a`，没有运行 RL-FP 训练或推理。

一次 E2E 指从固定初始 PCR 启动一次 CLI，到其自动循环结束并导出结果。CLI 内部的 FullProf 多次调用、试参和回滚均属于这一次 E2E。预先设置单样品上限 3600 秒；六个样品均自然退出，退出码均为 0，没有触及上限。环境预检只运行发行包自带 Y₂O₃，不计入这 6 个样品。

所有正式输入均在启动前完成语法读取检查，但初次检查没有发现 DAT 文件头遗漏。晶体相选择、CIF 化学适配、PCR 构造和 RAW 解码由执行者完成。因此本对照应表述为“辅助准备 CIF/PCR 后的 AutoFP 自动精修”，不能把这些步骤归入 AutoFP 原生端到端能力。

## 最终结果总表

全谱 Rwp 由冻结 PRF 中的 Yobs/Ycalc 复算，采用 w=1/max(Yobs,1)，仅作统一观察口径；PRF 强度已经过原生文本输出的舍入。没有再次调用精修引擎。AutoFP 原生 Rwp 取最终 CLI 总结，归一化使用扣背景后的 Ynet。二者分别保留。

| 样品 | 全谱 Rwp 复算 / % | AutoFP 原生 Rwp / % | 自动循环 | CLI 用时 | 产物判断 |
|---|---:|---:|---:|---|---|
| Fe2O3_Fe3O4_2ph | 1.542 | 25.90 | 3 | 0 分 40.7 秒 | 产物存在物理异常 |
| Fluoroapatite | 86.548 | 100.00 | 1 | 0 分 17.1 秒 | 拟合退化或相比例因子塌缩 |
| FE50 | 26.953 | 27.00 | 30 | 10 分 38.6 秒 | 产物存在物理异常 |
| LayeredOxide | 9.295 | 9.66 | 3 | 1 分 54.5 秒 | 产物存在物理异常 |
| LiFePO4 | 5.909 | 13.80 | 2 | 0 分 39.7 秒 | 产物存在物理异常 |
| Amorphous | 8.798 | 9.43 | 5 | 0 分 51.5 秒 | 非晶任务超出本路线适用范围 |

CLI 总运行时间为 15 分 2.1 秒。该时间包含 AutoFP 和其内部 FullProf 调用，不包含结构检索、数据准备、外层报告整理和保存时间。

**Rwp 不能混用。** FullProf OUT 同时列出全谱 `R-Factors` 和 `Conventional Rietveld`（Ynet）指标，AutoFP 使用后者。铁氧化物双相例的全谱 Rwp 约 1.54%，原生 Rwp 25.9%。若 DSH-XRD/GSAS-II 使用全谱归一化，直接拿 25.9% 比较会产生错误结论。要形成论文对照，仍需统一数据范围、逐点权重和归一化定义。

## 实际导入的数据

输入文件保留原始数值，没有平滑、Kα₂ 剥离或人工扣背景。FullProf 实际读取情况如下。

| 样品 | 输入点数 | 实际点数 | 略去点数 | 输入范围 / ° | 实际范围 / ° |
|---|---:|---:|---:|---|---|
| Fe2O3_Fe3O4_2ph | 4230 | 4224 | 6 | 10.01313–119.96713 | 10.16913–119.96713 |
| Fluoroapatite | 5752 | 5746 | 6 | 15.00000–130.02000 | 15.12000–130.02000 |
| FE50 | 2802 | 2796 | 6 | 10.00000–70.00110 | 10.12850–70.00110 |
| LayeredOxide | 3432 | 3432 | 0 | 10.00000–79.99670 | 10.00000–79.99670 |
| LiFePO4 | 7001 | 7001 | 0 | 10.00000–80.00000 | 10.00000–80.00000 |
| Amorphous | 3432 | 3432 | 0 | 10.00000–79.99670 | 10.00000–79.99670 |

其余原生可靠性指标如下，取 OUT 中与最终 CLI Rwp 匹配的记录；氟磷灰石采用此前匹配的接受记录，并单独保留末次 OUT 的差异。此处 Rp、Rexp 和 χ² 均为原生 Conventional Rietveld 口径。

| 样品 | Rp / % | Rexp / % | χ² | 与 CLI 匹配的 OUT 记录 |
|---|---:|---:|---:|---|
| Fe2O3_Fe3O4_2ph | 67.70 | 15.00 | 2.9850 | 末次 |
| Fluoroapatite | 122.00 | 6.48 | 238.0000 | 此前接受记录 |
| FE50 | 20.50 | 7.92 | 11.5800 | 末次 |
| LayeredOxide | 7.57 | 5.17 | 3.4920 | 末次 |
| LiFePO4 | 15.90 | 14.40 | 0.9220 | 末次 |
| Amorphous | 7.92 | 3.97 | 5.6230 | 末次 |

前三项 OUT 明示 `First 6 lines are considered as COMMENTS`。后三项六行文件头在唯一一次调用前补入，修改记录见 `data_header_correction.json`。所有原始文件保留在 `original_inputs`。

## 初始模型与参数

使用 TCH pseudo-Voigt（Npr=7）、六项多项式背景（Nba=0）和 FullProf 内部 NCY=10。初始背景为强度第 20 百分位；晶体样品初始 U/V/W=0.01/−0.01/0.01。石墨近似模型起始 W=4。波长和 Kα 比率优先采用输入元数据；Rigaku RAW 读取 Cu Kα 波长，未提供的强度比使用 0.5。氟磷灰石采用元数据给出的 Cthm=0.7，其余用模板 0.91。缺失或非正的初始 Biso 取 0.5 Å²。未使用最终精修结果或已知相比例来初始化。

PCR 占位使用 `site occupancy × multiplicity / general multiplicity`。报告中的最终位点占位已经转换回 CIF 的 site occupancy。Caglioti 展宽 U/V/W 与原子 Uiso 是不同物理量，不能只因一个 Caglioti 系数为负就判结构非物理。原子 Biso 与整体 Bov 同时释放时存在参数冗余，物理审查还计算 Biso+Bov，避免仅凭负 Biso 分量作错误判断。

## 逐样品报告

## Fe2O3_Fe3O4_2ph

本样品正式调用次数为 1，状态 `exited`，退出码 0，用时 0 分 40.7 秒。AutoFP 原生 Rwp 从 94.80% 变为 25.90%；冻结 PRF 全谱 Rwp 为 1.542%，PRF χ² 为 2.9847。

初始结构来源与适配：COD 9000139，Blake et al., American Mineralogist 51 (1966) 123–129；COD 9005837，Nakagiri et al., Physics and Chemistry of Minerals 13 (1986) 238–244，DOI 10.1007/BF00308275。后者为 0.63 GPa 结构，原子拓扑沿用，初始晶格改为常温近似 a=8.396 Å。

两相谱形在全谱强度口径下贴合较好，但赤铁矿 Fe 的有效 Biso+Bov 为负，氧位占位超过 1；磁铁矿也有超满占位。由最终 PCR 比例因子、ATZ 和晶胞体积计算的质量比例仅是该非物理模型的参数结果，不能作为可靠定量物相分析。该例直接说明：高背景样品的全谱低 Rwp 与扣背景 Rwp、结构可信度可以给出很不相同的判断。

| 相 | 晶格参数 a b c / Å | Bov / Å² | 最低有效 Biso+Bov / Å² | 比例因子 |
|---|---|---:|---:|---:|
| Hematite | 5.03738 / 5.03738 / 13.75622 | 22.6371 | -0.5753 | 0.0007542951 |
| Magnetite | 8.38952 / 8.38952 / 8.38952 | 16.9152 | 0.6021 | 0.0001457289 |

最终结构审查记录：

- phase1 negative raw Biso components (consider Bov gauge): Fe,O
- phase1 negative effective Biso+Bov: Fe=-0.5753
- phase1 occupancy outside [0,1]: Fe=1.001,O=1.244
- phase2 negative raw Biso components (consider Bov gauge): Fe1,Fe2,O
- phase2 occupancy outside [0,1]: Fe2=1.051,O=1.249

由最终 PCR 计算的模型质量比例为 63.08%, 36.92%。这些值继承最终占位/热参数的物理问题，不作有效定量相分数结论。

自动循环 3 次，日志中的参数尝试 249 次，已接受参数状态 183 项；回滚事件 66 次，奇异矩阵标记 7 次，PCR 转换错误 1 次，非有限数值错误标记 4 次。内部错误可由回滚恢复，不等于独立 E2E 失败次数。

轨迹中最低已接受原生 Rwp 为 25.90%；这是路径统计，没有用它替换最终 PCR 或再次精修。

末次 OUT 的 Ynet Rwp 与 CLI 最终总结一致；完整 OUT、PRF、PCR 和总结均保留。原生 PNG 图是否成功生成独立于数值拟合；CLI 的 EPS 导出出现缺少 backend_ps 的打包提示时，保留已有 PNG，不修改 CLI 包。

原生最终图如下，图中的 Rwp 标签采用 AutoFP 原生扣背景口径。

![Fe2O3_Fe3O4_2ph native fit](samples/Fe2O3_Fe3O4_2ph/run/autofp_prf2fig_job.png)

## Fluoroapatite

本样品正式调用次数为 1，状态 `exited`，退出码 0，用时 0 分 17.1 秒。AutoFP 原生 Rwp 从 100.00% 变为 100.00%；冻结 PRF 全谱 Rwp 为 86.548%，PRF χ² 为 237.7310。

初始结构来源与适配：COD 9001232，Hughes, Cameron and Crowley, American Mineralogist 74 (1989) 870–876，Durango 氟磷灰石，P63/m。

相比例因子降至 1×10⁻¹⁰，衍射峰基本未被晶体模型解释。大量坐标或不对称参数尝试出现数值溢出，PCR 中出现星号占位符，随后回滚。冻结 PRF 的全谱 Rwp 与 AutoFP 最终日志均显示拟合失败。原生 OUT 的末次记录与 CLI/PRF 所代表的最终接受状态不完全一致，因此保留不同记录，不把一个更低的末次试算值替换为正式最终值。最后一个原始强度为 0 的数据点也已原样保留；其存在记录为输入特征，未通过新增精修验证其对失败的贡献。

| 相 | 晶格参数 a b c / Å | Bov / Å² | 最低有效 Biso+Bov / Å² | 比例因子 |
|---|---|---:|---:|---:|
| Fluorapatite | 9.39730 / 9.39730 / 6.87820 | 0.0000 | 0.5000 | 1e-10 |

最终结构审查记录：

- phase1 collapsed phase scale=1e-10

CLI 最终 Rwp 为 100.0%；末次 OUT 的 Ynet Rwp 为 97.1%。OUT 内此前存在与 CLI 匹配的 100.0% 记录，冻结 PRF 复算全谱 Rwp 约 86.55%。这些文件的状态差异已作为产物一致性问题记录，全部原样保留。

自动循环 1 次，日志中的参数尝试 69 次，已接受参数状态 21 项；回滚事件 48 次，奇异矩阵标记 11 次，PCR 转换错误 20 次，非有限数值错误标记 7 次。内部错误可由回滚恢复，不等于独立 E2E 失败次数。

轨迹中最低已接受原生 Rwp 为 100.00%；这是路径统计，没有用它替换最终 PCR 或再次精修。

末次 OUT 的 Ynet Rwp 与 CLI 最终总结不一致；完整 OUT、PRF、PCR 和总结均保留。原生 PNG 图是否成功生成独立于数值拟合；CLI 的 EPS 导出出现缺少 backend_ps 的打包提示时，保留已有 PNG，不修改 CLI 包。

原生最终图如下，图中的 Rwp 标签采用 AutoFP 原生扣背景口径。

![Fluoroapatite native fit](samples/Fluoroapatite/run/autofp_prf2fig_job.png)

## FE50

本样品正式调用次数为 1，状态 `exited`，退出码 0，用时 10 分 38.6 秒。AutoFP 原生 Rwp 从 95.50% 变为 27.00%；冻结 PRF 全谱 Rwp 为 26.953%，PRF χ² 为 11.5819。

初始结构来源与适配：上传 candidate_A，保留 Fm-3m 拓扑；N 配位金属位改为 Fe/Mn 0.5/0.5，K 初始占位 0.73，Fe(CN)₆/C/N 初始占位 0.97。上传的 candidate_B 含 Sb，未将该元素引入提示词对应的样品。

固定的立方 Fe/Mn 混占模型经历了长时间自动选参、回滚与循环。数值降低没有形成可用的缺陷结构：有效热参数为负，N 位占位严重超过 1，立方晶胞 a 从 10.201 Å 膨胀到 18.43553 Å。最近 C–N 距离从初始约 1.173 Å 增至 1.40958 Å，也提示原氰基拓扑的化学合理性失去保障。该次没有自动建立另一种对称性或有物理约束的空位/分裂位模型；candidate_B 没有另行精修。结论局限于本次立方初始模型和默认专家系统策略，不能据此证明 FE50 的真实空间群、缺陷类型或对立方模型作最终物相否定。

| 相 | 晶格参数 a b c / Å | Bov / Å² | 最低有效 Biso+Bov / Å² | 比例因子 |
|---|---|---:|---:|---:|
| Cubic_K_FeMn_hexacyanoferrate | 18.43553 / 18.43553 / 18.43553 | 0.5806 | -3.8402 | 1.685444e-05 |

最终结构审查记录：

- phase1 negative raw Biso components (consider Bov gauge): K1,FeC
- phase1 negative effective Biso+Bov: K1=-2.511,FeC=-3.84
- phase1 occupancy outside [0,1]: N1=18.02

冻结 PCR 中 C1 到最近 N 的距离为 1.40958 Å，采用当前晶胞、全部空间群等价位置及周期边界计算。

自动循环 30 次，日志中的参数尝试 1918 次，已接受参数状态 209 项；回滚事件 1711 次，奇异矩阵标记 351 次，PCR 转换错误 101 次，非有限数值错误标记 194 次。内部错误可由回滚恢复，不等于独立 E2E 失败次数。

轨迹中最低已接受原生 Rwp 为 26.70%；这是路径统计，没有用它替换最终 PCR 或再次精修。

末次 OUT 的 Ynet Rwp 与 CLI 最终总结一致；完整 OUT、PRF、PCR 和总结均保留。原生 PNG 图是否成功生成独立于数值拟合；CLI 的 EPS 导出出现缺少 backend_ps 的打包提示时，保留已有 PNG，不修改 CLI 包。

原生最终图如下，图中的 Rwp 标签采用 AutoFP 原生扣背景口径。

![FE50 native fit](samples/FE50/run/autofp_prf2fig_job.png)

## LayeredOxide

本样品正式调用次数为 1，状态 `exited`，退出码 0，用时 1 分 54.5 秒。AutoFP 原生 Rwp 从 98.20% 变为 9.66%；冻结 PRF 全谱 Rwp 为 9.295%，PRF χ² 为 3.4916。

初始结构来源与适配：COD 4002260，Paulsen, Donaberger and Dahn, Chemistry of Materials 12 (2000) 2257–2267，P2 原型；按 Na₀.₇₂Ni₀.₃₃Mn₀.₆₂Mo₀.₀₅O₂ 投料比适配。Na₂MoO₄ 取 COD 2240655，Fortes, Acta Crystallographica E 71 (2015) 592–596，DOI 10.1107/S2056989015008774。

输入已包含 P2 型层状主相和 Na₂MoO₄ 候选；这来自测试执行者的检索和建模，并非 AutoFP 自动识相。主相 Mn/Ni/Mo 共用位点的总占位为 1.424，多个有效热参数为负；Na₂MoO₄ 的 a 从 9.10888 Å 缩至 6.52935 Å。尽管两种 Rwp 均小于 10%，这些结构异常仍使输出不能作为发表级结构或可靠相分数。最终质量比例只视作当前模型的数值参数。主相按投料比初始化，不能将它当作实测组成；本次未加入跨相 Mo 或 Na 质量守恒约束。

| 相 | 晶格参数 a b c / Å | Bov / Å² | 最低有效 Biso+Bov / Å² | 比例因子 |
|---|---|---:|---:|---:|
| P2_NaNiMnMoO2 | 2.88511 / 2.88511 / 11.14549 | -2.0931 | -7.1773 | 0.0006273153 |
| Na2MoO4 | 6.52935 / 6.52935 / 6.52935 | 0.0000 | 0.5843 | 0.0009757431 |

最终结构审查记录：

- phase1 negative raw Biso components (consider Bov gauge): O1
- phase1 negative effective Biso+Bov: Mn1=-1.593,O1=-7.177,Ni1=-1.593,Mo1=-1.593
- phase1 occupancy outside [0,1]: Mn1=1.044
- phase1 mixed site occupancy sum=1.424: Mn1,Ni1,Mo1

由最终 PCR 计算的模型质量比例为 1.26%, 98.74%。这些值继承最终占位/热参数的物理问题，不作有效定量相分数结论。

自动循环 3 次，日志中的参数尝试 309 次，已接受参数状态 134 项；回滚事件 175 次，奇异矩阵标记 14 次，PCR 转换错误 9 次，非有限数值错误标记 84 次。内部错误可由回滚恢复，不等于独立 E2E 失败次数。

轨迹中最低已接受原生 Rwp 为 9.66%；这是路径统计，没有用它替换最终 PCR 或再次精修。

末次 OUT 的 Ynet Rwp 与 CLI 最终总结一致；完整 OUT、PRF、PCR 和总结均保留。原生 PNG 图是否成功生成独立于数值拟合；CLI 的 EPS 导出出现缺少 backend_ps 的打包提示时，保留已有 PNG，不修改 CLI 包。

原生最终图如下，图中的 Rwp 标签采用 AutoFP 原生扣背景口径。

![LayeredOxide native fit](samples/LayeredOxide/run/autofp_prf2fig_job.png)

## LiFePO4

本样品正式调用次数为 1，状态 `exited`，退出码 0，用时 0 分 39.7 秒。AutoFP 原生 Rwp 从 64.80% 变为 13.80%；冻结 PRF 全谱 Rwp 为 5.909%，PRF χ² 为 0.9220。

初始结构来源与适配：COD 1101111，MAUD software 提交的 Pnma LiFePO₄ 结构；公开条目未给出完整论文出处，来源可追溯性弱于其他文献结构。该 CIF 中非正初始 Biso 改为 0.5 Å²，并加入配对 1% Li/Fe 反位。Rigaku FI/BU RAW 由 Profex 5.7.2 的 loadNew 字段定义解码，7001 点以及文件字节数严格吻合。

输入中已给出 Li/Fe 反位模型，初始反位为 1%。该数值只是预先规定的起点，未使用既往实验得到的反位率。AutoFP 默认自动选参可以独立改变占位、热参数和坐标，不能保证配对反位、总 Li/Fe 守恒或同位原子坐标绑定。最终 FeLi 占位 −0.04852、LiFe 占位 −0.00012，Li 主位占位 1.77326；该结果不能给出有效的定量反位率。多个有效热参数也为负。本次输出的反位位原始参数完整列入审查文件。

| 相 | 晶格参数 a b c / Å | Bov / Å² | 最低有效 Biso+Bov / Å² | 比例因子 |
|---|---|---:|---:|---:|
| LiFePO4_antisite_start1pct | 10.32821 / 6.00664 / 4.69124 | -1.0913 | -0.9716 | 0.0007710373 |

最终结构审查记录：

- phase1 negative effective Biso+Bov: Fe1=-0.5913,Li1=-0.5913,P1=-0.7877,O2=-0.04232,O3=-0.9716,FeLi=-0.5913,LiFe=-0.5913
- phase1 occupancy outside [0,1]: Li1=1.773,FeLi=-0.04852
- phase1 mixed site occupancy sum=1.725: Li1,FeLi

| 位点原子 | 最终坐标 x y z | site occupancy | Biso+Bov / Å² |
|---|---|---:|---:|
| Fe1 | 0.28202 / 0.25000 / 0.97302 | 0.89272 | -0.5913 |
| Li1 | 0.00000 / 0.00000 / 0.00000 | 1.77326 | -0.5913 |
| FeLi | 0.00000 / 0.00000 / 0.00000 | -0.04852 | -0.5913 |
| LiFe | 0.28202 / 0.25000 / 0.97302 | -0.00012 | -0.5913 |

自动循环 2 次，日志中的参数尝试 148 次，已接受参数状态 129 项；回滚事件 19 次，奇异矩阵标记 4 次，PCR 转换错误 0 次，非有限数值错误标记 1 次。内部错误可由回滚恢复，不等于独立 E2E 失败次数。

轨迹中最低已接受原生 Rwp 为 13.80%；这是路径统计，没有用它替换最终 PCR 或再次精修。

末次 OUT 的 Ynet Rwp 与 CLI 最终总结一致；完整 OUT、PRF、PCR 和总结均保留。原生 PNG 图是否成功生成独立于数值拟合；CLI 的 EPS 导出出现缺少 backend_ps 的打包提示时，保留已有 PNG，不修改 CLI 包。

原生最终图如下，图中的 Rwp 标签采用 AutoFP 原生扣背景口径。

![LiFePO4 native fit](samples/LiFePO4/run/autofp_prf2fig_job.png)

## Amorphous

本样品正式调用次数为 1，状态 `exited`，退出码 0，用时 0 分 51.5 秒。AutoFP 原生 Rwp 从 92.40% 变为 9.43%；冻结 PRF 全谱 Rwp 为 8.798%，PRF χ² 为 5.6227。

初始结构来源与适配：根据标准 AB 石墨 P63/mmc 拓扑构建边界用模型，a=2.46 Å、c=6.71 Å，两个独立 C 位；没有从晶体数据库得到能够描述该非晶碳管的 CIF。

该样品的任务是处理多层无定形碳管壁。石墨近似 CIF 只用于一次边界探测；它表示周期性 AB 石墨，不是该非晶样品的结构模型。最终 a=2.22103 Å、c=4.19484 Å，相比初始 AB 石墨出现大幅收缩，不能作为可信石墨结构。AutoFP 的专家系统没有在本次 CLI 路线中提供非晶散射、分相或多层碳结构诊断。因此该结果不计为非晶科学任务成功，也不能将最终石墨晶格参数解释为真实碳管壁结构。

| 相 | 晶格参数 a b c / Å | Bov / Å² | 最低有效 Biso+Bov / Å² | 比例因子 |
|---|---|---:|---:|---:|
| Graphite_proxy_only | 2.22103 / 2.22103 / 4.19484 | 3.4243 | 3.9243 | 32.4787 |

最终结构审查记录：

- 当前脚本未发现上述硬性异常；这不替代完整晶体学验证。

自动循环 5 次，日志中的参数尝试 220 次，已接受参数状态 73 项；回滚事件 147 次，奇异矩阵标记 30 次，PCR 转换错误 4 次，非有限数值错误标记 44 次。内部错误可由回滚恢复，不等于独立 E2E 失败次数。

轨迹中最低已接受原生 Rwp 为 9.42%；这是路径统计，没有用它替换最终 PCR 或再次精修。

末次 OUT 的 Ynet Rwp 与 CLI 最终总结一致；完整 OUT、PRF、PCR 和总结均保留。原生 PNG 图是否成功生成独立于数值拟合；CLI 的 EPS 导出出现缺少 backend_ps 的打包提示时，保留已有 PNG，不修改 CLI 包。

原生最终图如下，图中的 Rwp 标签采用 AutoFP 原生扣背景口径。

![Amorphous native fit](samples/Amorphous/run/autofp_prf2fig_job.png)

## 结果的对照用途

本批次提供了可审计的单次运行产物和明确的失败路径。可用于讨论自动选参的运行完成情况、默认专家系统的物理边界，以及低 Rwp 与结构合理性的关系。不能把六个正常退出码当作六个科学成功，也不能把输入适配错误作为 AutoFP 的算法失败。

对 DSH-XRD 的正式比较应明确任务范围：本次 AutoFP 的物相、缺陷位点和杂质候选已经由执行者提供；DSH-XRD 如果承担原始数据理解、数据库检索和模型升级，其能力范围更宽。论文既可以比较同一初始 CIF/PCR 下的精修，也可以比较各自全流程，但应分别说明，且统一 Rwp 口径。本次没有另一工具在这些样品上的冻结结果，因而没有计算相对胜负或加速比。该批次不自动证明任何系统的一般优越性。

上传提示词中明确要求 Fe2O3_Fe3O4_2ph、FE50 和 LayeredOxide 尽可能达到 R≤10。铁氧化物仅全谱复算口径达标而原生口径不达标；FE50 两种口径均不达标；层状氧化物两种口径均达标但结构不合理。LiFePO4 的低 R 值未转化为有效反位率，氟磷灰石未实现峰拟合，非晶样品未完成非晶工作流。R 阈值不单独作为发表级成功判据。

## 固定产物与复核方式

每个样品保存：初始 CIF、PCR、DAT、输入假设 JSON；唯一一次调用的命令、时间和 SHA-256；完整标准输出/错误日志；原生最终 PCR、PRF、OUT、SUM、PNG、参数轨迹、回滚快照与备份；静态转写的 `unvalidated_final_phase_*.cif` 和结构审查 JSON。

原生 PCR 是最终精修参数的权威文件。导出的最终 CIF 标注为未验证诊断产物，完整保留异常占位和热参数，没有通过修改得到“物理正确”的假结果。CIF 还记录非标准的 `_autofp_phase_overall_Bov` 字段；常规 CIF 软件未必使用该字段，故不能把它当作可直接发表或完全等价复现散射的结构。

正式调用结束后的原生文件清单已经再次进行稳定性与 SHA-256 校验。氟磷灰石有三个原生文件在首份 CLI 退出快照后发生字节差异；初次和最终清单都保留在该样品 `attempt_001.json`，最终冻结采用稳定后的文件，未增加引擎调用。用时采用外层单调时钟；原生 FullProf 文字时间与外层 UTC 相差四小时，不混用两类时间戳计算用时。

`results.json` 和 `results.csv` 包含机器可读结果，`protocol.md` 记录事前设置及偏差。`scripts` 保存准备、一次运行、冻结核验和报告生成代码。执行者未修改 AutoFP 或 FullProf 算法。原 CLI 因已单独提供，不重复装入结果包；固定版本下载地址和哈希在 `SOFTWARE.json`。

## 公开来源

- AutoFP 官方仓库：https://github.com/xpclove/autofp/
- 固定发布版本：https://github.com/xpclove/autofp/releases/tag/v1.7b15
- AutoFP 文献：Cui et al. (2015), AutoFP: a GUI for highly automated Rietveld refinement using an expert system algorithm based on FullProf, Journal of Applied Crystallography 48, 1581–1586，https://doi.org/10.1107/S1600576715015125。
- FullProf 作者手册（PSI 镜像）：https://psi.ch/sinq/dmc/ManualsEN/fullprof.pdf；PDF 第 57–58 页讨论结构因子和整体温度因子，第 110 页定义 Bov。混占位置及热参数约束还参考官方命令说明：https://www.ill.eu/other_sites/fullprof/downloads/Docs/FP_COMMANDS.pdf。
- 原始结构 COD 条目：https://www.crystallography.net/cod/9000139.html, https://www.crystallography.net/cod/9005837.html, https://www.crystallography.net/cod/9001232.html, https://www.crystallography.net/cod/4002260.html, https://www.crystallography.net/cod/2240655.html, https://www.crystallography.net/cod/1101111.html
- Rigaku RAW 解码实现：Profex 5.7.2 官方源代码，https://www.profex-xrd.org/wp-content/uploads/2026/08/profex-5.7.2.tar.gz；相关 GPL 源文件在 provenance 中保留。
