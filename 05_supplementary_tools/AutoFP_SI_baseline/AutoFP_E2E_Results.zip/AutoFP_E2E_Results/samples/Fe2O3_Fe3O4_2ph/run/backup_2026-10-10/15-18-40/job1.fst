!   FILE for FullProf Studio: generated automatically by FullProf 
!Title: Hematite                                                                                                                                                            
SPACEG R -3 c              
CELL     5.037396    5.037396   13.756150  90.0000  90.0000 120.0000   DISPLAY MULTIPLE
BOX   -0.15  1.15   -0.15  1.15    -0.15  1.15 
ATOM Fe      Fe       0.00000   0.00000   0.35503  
ATOM O       O        0.31429   0.00000   0.25000  
