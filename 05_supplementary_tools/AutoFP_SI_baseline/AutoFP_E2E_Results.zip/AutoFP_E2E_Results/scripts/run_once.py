from pathlib import Path
import json,subprocess,os,time,datetime,hashlib,signal,platform
BASE=Path(__file__).resolve().parents[1];CLI=BASE.parents[1]/'upload/autofp-cli'
order=['Fe2O3_Fe3O4_2ph','Fluoroapatite','FE50','LayeredOxide','LiFePO4','Amorphous']
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
for name in order:
 d=BASE/'samples'/name;job=d/'run';lock=d/'attempt_001.json'
 if lock.exists():raise RuntimeError(f'Refusing a second attempt: {name}')
 before={str(f.relative_to(d/'input')):hashlib.sha256(f.read_bytes()).hexdigest() for f in (d/'input').glob('*') if f.is_file()}
 info={'sample':name,'attempt':1,'start_utc':utc(),'command':[str(CLI),'-c','0','-a',str(job/'job.pcr')],'input_sha256':before,'timeout_seconds':3600,'state':'running'}
 with lock.open('x') as f:json.dump(info,f,indent=2)
 print('START',name,utc(),flush=True);t=time.monotonic()
 env=dict(os.environ,PYTHONUNBUFFERED='1',MPLBACKEND='Agg',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
 with (d/'stdout_stderr.log').open('wb') as log:
  p=subprocess.Popen(info['command'],cwd=job,stdout=log,stderr=subprocess.STDOUT,env=env,start_new_session=True)
  info['pid']=p.pid;lock.write_text(json.dumps(info,indent=2))
  try:p.wait(timeout=3600);info['state']='exited';info['returncode']=p.returncode
  except subprocess.TimeoutExpired:
   os.killpg(p.pid,signal.SIGTERM)
   try:p.wait(timeout=10)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
   info['state']='timeout';info['returncode']=p.returncode
 info.update(end_utc=utc(),elapsed_seconds=round(time.monotonic()-t,3))
 # Preserve native bytes exactly. No further engine invocation.
 info['output_sha256']={str(f.relative_to(job)):hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted(job.rglob('*')) if f.is_file()}
 lock.write_text(json.dumps(info,indent=2));print('END',name,info['state'],info['returncode'],info['elapsed_seconds'],flush=True)
print('ALL FORMAL ATTEMPTS FROZEN',utc(),flush=True)
