!   FILE for FullProf Studio: generated automatically by FullProf 
!Title: LiFePO4_antisite_start1pct                                                                                                                                          
SPACEG P n m a             
CELL    10.328205    6.006641    4.691237  90.0000  90.0000  90.0000   DISPLAY MULTIPLE
BOX   -0.15  1.15   -0.15  1.15    -0.15  1.15 
ATOM Fe1     Fe       0.28202   0.25000   0.97302  
ATOM Li1     Li       0.00000   0.00000   0.00000  
ATOM P1      P        0.09594   0.25000   0.42502  
ATOM O1      O        0.09011   0.25000   0.74096  
ATOM O2      O        0.45546   0.25000   0.21838  
ATOM O3      O        0.16099   0.04801   0.28414  
ATOM FeLi    Fe       0.00000   0.00000   0.00000  
ATOM LiFe    Li       0.28202   0.25000   0.97302  
