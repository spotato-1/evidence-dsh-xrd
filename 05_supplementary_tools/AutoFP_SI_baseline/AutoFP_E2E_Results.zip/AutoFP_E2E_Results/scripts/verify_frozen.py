"""Read-only verification. Never invokes refinement engines or writes artifacts."""
from pathlib import Path
import hashlib
import json

BASE = Path(__file__).resolve().parents[1]
NAMES = ('Fe2O3_Fe3O4_2ph', 'Fluoroapatite', 'FE50', 'LayeredOxide', 'LiFePO4', 'Amorphous')

def digest(path):
    with path.open('rb') as handle:
        return hashlib.file_digest(handle, 'sha256').hexdigest()

checked = 0
for name in NAMES:
    folder = BASE / 'samples' / name
    records = list(folder.glob('attempt_*.json'))
    assert len(records) == 1 and records[0].name == 'attempt_001.json', (name, records)
    attempt = json.loads(records[0].read_text())
    assert attempt['attempt'] == 1 and attempt['state'] == 'exited', name
    assert attempt['returncode'] == 0 and attempt['elapsed_seconds'] < attempt['timeout_seconds'], name
    for section, root in [('input_sha256', folder / 'input'), ('output_sha256', folder / 'run')]:
        expected = attempt[section]
        actual = {str(p.relative_to(root)) for p in root.rglob('*') if p.is_file()}
        assert actual == set(expected), (name, section, actual.symmetric_difference(expected))
        for relative, sha256 in expected.items():
            assert digest(root / relative) == sha256, (name, section, relative)
            checked += 1
    for suffix in ['pcr', 'prf', 'out', 'sum']:
        assert (folder / 'run' / ('job.' + suffix)).is_file(), (name, suffix)
    assert (folder / 'run' / 'autofp_prf2fig_job.png').is_file(), name
    print(name, 'one attempt; exit 0; input and native bytes verified')

manifest = BASE / 'SHA256SUMS.txt'
if manifest.exists():
    expected = {}
    for line in manifest.read_text().splitlines():
        sha256, relative = line.split('  ', 1)
        expected[relative] = sha256
    actual = {str(p.relative_to(BASE)) for p in BASE.rglob('*') if p.is_file() and p != manifest}
    assert actual == set(expected), ('complete package inventory', actual.symmetric_difference(expected))
    for relative, sha256 in expected.items():
        assert digest(BASE / relative) == sha256, ('complete package hash', relative)
    print('Complete package manifest verified:', len(expected), 'files')
print('Frozen input/native files verified:', checked)
