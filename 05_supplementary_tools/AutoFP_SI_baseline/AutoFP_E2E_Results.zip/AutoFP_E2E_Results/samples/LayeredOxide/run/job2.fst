!   FILE for FullProf Studio: generated automatically by FullProf 
!Title: Na2MoO4                                                                                                                                                             
SPACEG F d -3 m            
CELL     6.529349    6.529349    6.529349  90.0000  90.0000  90.0000   DISPLAY MULTIPLE
BOX   -0.15  1.15   -0.15  1.15    -0.15  1.15 
ATOM O       O        0.26271   0.26271   0.26271  
ATOM Mo      Mo       0.37500   0.37500   0.37500  
ATOM Na      Na       0.00000   0.00000   0.00000  
