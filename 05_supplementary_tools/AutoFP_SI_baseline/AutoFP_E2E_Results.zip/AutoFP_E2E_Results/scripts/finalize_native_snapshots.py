from pathlib import Path
import hashlib,json,datetime,time
BASE=Path(__file__).resolve().parents[1]
def snap(job):return {str(f.relative_to(job)):hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted(job.rglob('*')) if f.is_file()}
for d in sorted((BASE/'samples').iterdir()):
 p=d/'attempt_001.json'
 if not p.exists():continue
 a=json.loads(p.read_text())
 if a['state']=='running':continue
 current=snap(d/'run');time.sleep(1);again=snap(d/'run')
 if again!=current:raise RuntimeError(f'Native files still changing: {d.name}')
 if a['output_sha256']!=current:
  a['output_sha256_at_cli_exit']=a['output_sha256']
  a['changed_after_cli_exit_snapshot']=[k for k in current if current[k]!=a['output_sha256'].get(k)]
  a['output_sha256']=current
 a['native_snapshot_stability_check_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
 p.write_text(json.dumps(a,indent=2))
 print(d.name,'stable',len(current),'native files','changed since first snapshot',a.get('changed_after_cli_exit_snapshot',[]))
