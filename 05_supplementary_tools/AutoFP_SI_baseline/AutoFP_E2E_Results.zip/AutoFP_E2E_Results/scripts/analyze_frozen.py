from pathlib import Path
import json,re,math,csv,hashlib,collections
import numpy as np
import gemmi
BASE=Path(__file__).resolve().parents[1]
FLOAT=r'[-+]?(?:\d*\.\d+|\d+\.?)(?:[EeDd][-+]?\d+)?'
def nums(s):return [float(x.replace('D','E').replace('d','e')) for x in re.findall(FLOAT,s)]
def get_after(lines,key):
 i=next(i for i,l in enumerate(lines) if key in l)
 return nums(lines[i+1])
def parse_pcr(path):
 text=path.read_text(errors='replace')
 pieces=re.split(r'!\s*Data for PHASE number:\s*\d+[^\n]*\n',text)[1:]
 phases=[]
 for p in pieces:
  if '*' in p:raise ValueError('Overflow stars in final PCR; refusing to invent numerical values')
  lines=p.splitlines();natpar=get_after(lines,'!Nat');nat=natpar[0];atz=natpar[7]
  sgline=next(l for l in lines if '<--Space group symbol' in l)
  sgname=sgline.split('<--')[0].strip();sg=gemmi.find_spacegroup_by_name(sgname)
  # FullProf Fd-3m convention used here is origin 2, matching supplied coordinates.
  if sgname.replace(' ','')=='Fd-3m':sg=gemmi.find_spacegroup_by_name('F d -3 m:2')
  i=next(i for i,l in enumerate(lines) if l.startswith('!Atom'))+1
  aa=[]
  while i<len(lines) and len(aa)<nat:
   m=re.match(r'^\s*([A-Za-z][\w-]*)\s+([A-Za-z][\w+\-]*)\s+(.*)$',lines[i])
   if m:
    v=nums(m[3]);assert len(v)>=5,(lines[i],v)
    aa.append(dict(label=m[1],element=re.match('[A-Z][a-z]?',m[2]).group(),xyz=v[:3],biso=v[3],pcr_occ=v[4]))
   i+=1
  cell=get_after(lines,'!     a ' )[:6]
  scalepar=get_after(lines,'!  Scale');scale=scalepar[0];bov=scalepar[2]
  profile=get_after(lines,'!       U')[:7]
  bname=lines[next(i for i,l in enumerate(lines) if l.startswith('!Nat'))-2].strip()
  for a in aa:
   positions=[]
   for op in sg.operations():
    q=np.mod(op.apply_to_xyz(a['xyz']),1)
    if not any(np.max(np.abs((q-r+.5)%1-.5))<1e-4 for r in positions):positions.append(q)
   a['multiplicity']=len(positions);a['site_occupancy']=a['pcr_occ']*len(sg.operations())/len(positions);a['effective_Biso_plus_Bov']=a['biso']+bov
  phases.append(dict(name=bname,sg=sg.xhm(),cell=cell,scale=scale,ATZ=atz,overall_Bov=bov,profile_UVWXY=profile,atoms=aa))
 return phases

def cif_export(phase,path):
 sg=gemmi.find_spacegroup_by_name(phase['sg']);d=gemmi.cif.Document();b=d.add_new_block('unvalidated_AutoFP_output')
 for k,v in zip(['a','b','c','alpha','beta','gamma'],phase['cell']):b.set_pair('_cell_'+('length_' if k in ['a','b','c'] else 'angle_')+k,str(v))
 b.set_pair('_space_group_name_H-M_alt',gemmi.cif.quote(sg.xhm()));b.set_pair('_space_group_IT_number',str(sg.number))
 b.set_pair('_autofp_phase_overall_Bov',str(phase['overall_Bov']))
 b.set_pair('_audit_creation_method',gemmi.cif.quote('Static transcription of frozen AutoFP PCR; NOT a validated scientific structure; no new refinement; rounding inherited from native PCR'))
 l=b.init_loop('_space_group_symop_',['operation_xyz'])
 for op in sg.operations():l.add_row([gemmi.cif.quote(op.triplet())])
 l=b.init_loop('_atom_site_',['label','type_symbol','fract_x','fract_y','fract_z','occupancy','B_iso_or_equiv'])
 for a in phase['atoms']:l.add_row([a['label'],a['element']]+[str(v) for v in a['xyz']]+[str(a['site_occupancy']),str(a['biso'])])
 d.write_file(str(path))

def bond_min(phase,e1,e2):
 sg=gemmi.find_spacegroup_by_name(phase['sg']);cell=gemmi.UnitCell(*phase['cell']);a1=[a for a in phase['atoms'] if a['element']==e1];a2=[a for a in phase['atoms'] if a['element']==e2]
 out=[]
 for a in a1:
  dd=[]
  for b in a2:
   for op in sg.operations():
    v=op.apply_to_xyz(b['xyz']);dist=cell.find_nearest_pbc_image(gemmi.Fractional(*a['xyz']),gemmi.Fractional(*v),0).dist()
    if dist>1e-5:dd.append(dist)
  if dd:out.append({'from_atom':a['label'],'nearest_'+e2+'_angstrom':min(dd)})
 return out

results=[]
for name in ['Fe2O3_Fe3O4_2ph','Fluoroapatite','FE50','LayeredOxide','LiFePO4','Amorphous']:
 d=BASE/'samples'/name
 if not (d/'attempt_001.json').exists():continue
 info=json.loads((d/'attempt_001.json').read_text())
 if info['state']=='running':continue
 job=d/'run';derived=d/'derived';derived.mkdir(exist_ok=True)
 # Confirm no native product byte has been changed since the end of the only process.
 for rel,h in info['output_sha256'].items():assert hashlib.sha256((job/rel).read_bytes()).hexdigest()==h,(name,rel)
 inp=json.loads((d/'input/inputs.json').read_text());log=(d/'stdout_stderr.log').read_text(errors='replace')
 r=dict(sample=name,attempts=info['attempt'],state=info['state'],returncode=info.get('returncode'),elapsed_seconds=info['elapsed_seconds'],input_points=inp['points'],input_range=inp['range'])
 summary=log.split('=== Refinement Complete ===')[-1]
 for key,pat in [('autofp_Rwp',r'^Rwp:\s*('+FLOAT+')'),('initial_autofp_Rwp',r'^Rwp Initial:\s*('+FLOAT+')')]:
  m=re.search(pat,summary,re.M);r[key]=float(m[1]) if m else None
 alg=json.loads((job/'autofp.log').read_text()) if (job/'autofp.log').exists() else {}
 cycles=sorted([(int(k.split('_')[1]),v) for k,v in alg.items() if k.startswith('cycle_')]);r['cycles']=len(cycles)
 r['accepted_parameter_states']=sum(len(v.get('good_rwplist',[])) for _,v in cycles)
 r['parameter_attempts']=len(re.findall(r'^--- Cycle \d+ \[\d+%\] \| Refining:',log,re.M))
 r['min_accepted_Rwp_in_trace']=min([x for _,v in cycles for x in v.get('good_rwplist',[])] or [float('nan')])
 r['FullProf_finished_events']=log.count('>>> fp2k is finished.')
 r['cycle_trace']=[dict(cycle=k,start_Rwp=v.get('good_rwplist',[None])[0],end_Rwp=v.get('good_rwplist',[None])[-1],accepted_states=len(v.get('good_rwplist',[]))) for k,v in cycles]
 r['backtracks']=len(re.findall(r'^back\s+\d',log,re.M));r['singular_matrix_events']=log.count('error code= -33');r['PCR_parse_errors']=log.count('Error Type:  RietPCRError');r['nonfinite_events']=len(re.findall(r'fp2k error -34',log));r['plot_EPS_failure']='backend_ps' in log
 out=(job/'job.out').read_text(errors='replace') if (job/'job.out').exists() else ''
 records=[]
 for c in out.split('==> RELIABILITY FACTORS WITH ALL NON-EXCLUDED POINTS FOR PATTERN:')[1:]:
  c=c.split('==> RELIABILITY FACTORS FOR POINTS WITH BRAGG CONTRIBUTIONS')[0]
  raw=re.search(r'=> R-Factors:\s*('+FLOAT+')\s+('+FLOAT+')\s+Chi2:\s*('+FLOAT+')',c)
  conv=re.search(r'=> Conventional Rietveld Rp,Rwp,Re and Chi2:\s*('+FLOAT+')\s+('+FLOAT+')\s+('+FLOAT+')\s+('+FLOAT+')',c)
  if raw and conv:records.append(dict(raw_Rp=float(raw[1]),raw_Rwp=float(raw[2]),Chi2=float(raw[3]),net_Rp=float(conv[1]),net_Rwp=float(conv[2]),net_Rexp=float(conv[3]),net_Chi2=float(conv[4])))
 r['all_out_metric_records']=records;r['terminal_OUT_metrics']=records[-1] if records else None
 matched=[v for v in records if r['autofp_Rwp'] is not None and abs(v['net_Rwp']-r['autofp_Rwp'])<.05]
 r['OUT_record_matching_cli']=matched[-1] if matched else None
 r['terminal_OUT_matches_cli']=bool(records and r['autofp_Rwp'] is not None and abs(records[-1]['net_Rwp']-r['autofp_Rwp'])<.05)
 rng=re.search(r'2Thmin:\s*('+FLOAT+')\s+2Thmax:\s*('+FLOAT+')\s+Step:\s*('+FLOAT+')\s+No. of points:\s*(\d+)',out)
 if rng:r.update(engine_points=int(rng[4]),engine_range=[float(rng[1]),float(rng[2])])
 if (job/'job.prf').exists():
  lines=(job/'job.prf').read_text().splitlines();n=int(lines[1].split()[1]);a=np.array([[float(v) for v in l.split()[:5]] for l in lines[4:4+n]])
  assert len(a)==n;r['PRF_points']=n
  w=1/np.maximum(a[:,1],1.0)
  r['PRF_raw_Rwp_recomputed']=float(100*np.sqrt(np.sum(w*(a[:,1]-a[:,2])**2)/np.sum(w*a[:,1]**2)))
  r['PRF_raw_Rp_recomputed']=float(100*np.sum(np.abs(a[:,1]-a[:,2]))/np.sum(a[:,1]))
  r['PRF_chi2_header']=float(re.search(r'Chi2:\s*('+FLOAT+')',lines[0])[1])
  np.savetxt(derived/'frozen_profile.tsv',a,delimiter='\t',header='2theta\tYobs\tYcalc\tNative_shifted_difference\tNative_Background_column',comments='',fmt='%.10g')
 try:
  phases=parse_pcr(job/'job.pcr');r['final_phases']=phases
  weights=[ph['scale']*ph['ATZ']*gemmi.UnitCell(*ph['cell']).volume for ph in phases]
  r['PCR_weight_fractions_pct']=[100*v/sum(weights) for v in weights] if sum(weights)>0 else []
  issues=[]
  for i,ph in enumerate(phases,1):
   cif_export(ph,derived/f'unvalidated_final_phase_{i}.cif')
   neg=[a['label'] for a in ph['atoms'] if a['biso']<0]
   if neg:issues.append(f'phase{i} negative raw Biso components (consider Bov gauge): '+','.join(neg))
   negeff=[f"{a['label']}={a['effective_Biso_plus_Bov']:.4g}" for a in ph['atoms'] if a['effective_Biso_plus_Bov']<0]
   if negeff:issues.append(f'phase{i} negative effective Biso+Bov: '+','.join(negeff))
   bad=[f"{a['label']}={a['site_occupancy']:.4g}" for a in ph['atoms'] if a['site_occupancy']<-.001 or a['site_occupancy']>1.001]
   if bad:issues.append(f'phase{i} occupancy outside [0,1]: '+','.join(bad))
   # Sum occupancies for atoms sharing one crystallographic site (mixed occupation).
   sites=collections.defaultdict(list)
   for a in ph['atoms']:sites[tuple(round(x%1,4) for x in a['xyz'])].append(a)
   for aa in sites.values():
    if len(aa)>1 and sum(a['site_occupancy'] for a in aa)>1.001:issues.append(f'phase{i} mixed site occupancy sum={sum(a["site_occupancy"] for a in aa):.4g}: '+','.join(a['label'] for a in aa))
   if ph['scale']<=1e-8:issues.append(f'phase{i} collapsed phase scale={ph["scale"]:.3g}')
   if name=='FE50':ph['nearest_C_N']=bond_min(ph,'C','N')
   if name in ['LiFePO4','Fluoroapatite']:ph['nearest_P_O']=bond_min(ph,'P','O')
  r['physical_issues']=issues
 except Exception as e:r['PCR_static_read_error']=str(e);r['physical_issues']=['Cannot statically transcribe final PCR']
 r['engine_dropped_points']=inp['points']-r.get('engine_points',inp['points'])
 r['native_bytes_sha256_verified']=True
 (derived/'audit.json').write_text(json.dumps(r,indent=2,ensure_ascii=False));results.append(r)
(BASE/'results.json').write_text(json.dumps(results,indent=2,ensure_ascii=False))
fields=['sample','attempts','returncode','elapsed_seconds','cycles','parameter_attempts','input_points','engine_points','engine_dropped_points','initial_autofp_Rwp','autofp_Rwp','PRF_raw_Rwp_recomputed','PRF_raw_Rp_recomputed','PRF_chi2_header','terminal_OUT_matches_cli','singular_matrix_events','PCR_parse_errors','nonfinite_events']
with (BASE/'results.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore');w.writeheader();w.writerows(results)
for r in results:print(json.dumps({k:r.get(k) for k in fields+['physical_issues','PCR_static_read_error']},ensure_ascii=False))
