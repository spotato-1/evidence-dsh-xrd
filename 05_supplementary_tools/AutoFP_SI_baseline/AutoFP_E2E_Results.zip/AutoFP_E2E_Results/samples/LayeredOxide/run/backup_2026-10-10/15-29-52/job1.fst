!   FILE for FullProf Studio: generated automatically by FullProf 
!Title: P2_NaNiMnMoO2                                                                                                                                                       
SPACEG P 63/m m c          
CELL     2.885000    2.885000   11.155000  90.0000  90.0000 120.0000   DISPLAY MULTIPLE
BOX   -0.15  1.15   -0.15  1.15    -0.15  1.15 
ATOM Na2     Na       0.66667   0.33333   0.25000  
ATOM Na1     Na       0.00000   0.00000   0.25000  
ATOM Mn1     Mn       0.00000   0.00000   0.00000  
ATOM O1      O        0.66667   0.33333   0.09400  
ATOM Ni1     Ni       0.00000   0.00000   0.00000  
ATOM Mo1     Mo       0.00000   0.00000   0.00000  
