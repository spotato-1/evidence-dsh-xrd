!   FILE for FullProf Studio: generated automatically by FullProf 
!Title: LiFePO4_antisite_start1pct                                                                                                                                          
SPACEG P n m a             
CELL    10.325950    6.005331    4.690198  90.0000  90.0000  90.0000   DISPLAY MULTIPLE
BOX   -0.15  1.15   -0.15  1.15    -0.15  1.15 
ATOM Fe1     Fe       0.28202   0.25000   0.97302  
ATOM Li1     Li       0.00000   0.00000   0.00000  
ATOM P1      P        0.09595   0.25000   0.42513  
ATOM O1      O        0.08999   0.25000   0.74082  
ATOM O2      O        0.45545   0.25000   0.21846  
ATOM O3      O        0.16095   0.04816   0.28421  
ATOM FeLi    Fe       0.00000   0.00000   0.00000  
ATOM LiFe    Li       0.28202   0.25000   0.97302  
