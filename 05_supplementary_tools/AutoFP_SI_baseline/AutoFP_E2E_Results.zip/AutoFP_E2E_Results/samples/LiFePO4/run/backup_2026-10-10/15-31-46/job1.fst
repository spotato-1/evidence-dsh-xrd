!   FILE for FullProf Studio: generated automatically by FullProf 
!Title: LiFePO4_antisite_start1pct                                                                                                                                          
SPACEG P n m a             
CELL    10.332801    6.004301    4.697700  90.0000  90.0000  90.0000   DISPLAY MULTIPLE
BOX   -0.15  1.15   -0.15  1.15    -0.15  1.15 
ATOM Fe1     Fe       0.28160   0.25000   0.97500  
ATOM Li1     Li       0.00000   0.00000   0.00000  
ATOM P1      P        0.09480   0.25000   0.42300  
ATOM O1      O        0.09400   0.25000   0.74100  
ATOM O2      O        0.45300   0.25000   0.22700  
ATOM O3      O        0.16130   0.04700   0.28200  
ATOM FeLi    Fe       0.00000   0.00000   0.00000  
ATOM LiFe    Li       0.28160   0.25000   0.97500  
