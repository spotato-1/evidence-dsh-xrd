from pathlib import Path
import struct,json,re,hashlib,shutil,math
import numpy as np
import gemmi
BASE=Path(__file__).resolve().parents[1]
SCRATCH=BASE.parents[1]
RAW=SCRATCH/'work/agent_input'; SOURCE=SCRATCH/'work/sources'
SAMPLES=['Amorphous','Fe2O3_Fe3O4_2ph','FE50','Fluoroapatite','LayeredOxide','LiFePO4']

def get_model(path):
 b=gemmi.cif.read(str(path)).sole_block()
 s=gemmi.make_small_structure_from_block(b)
 if not s.spacegroup:
  name=next((gemmi.cif.as_string(b.find_value(k)) for k in ['_space_group_name_H-M_alt','_symmetry_space_group_name_H-M'] if b.find_value(k)),None)
  s.spacegroup_hm=name
 return s

def atoms(s):
 out=[]
 for a in s.sites:
  el=a.element.name
  if not el or el=='X':el=re.match('[A-Z][a-z]?',a.label).group()
  bi=8*math.pi**2*a.u_iso
  if bi<=0 or bi>5:bi=0.5
  out.append(dict(label=a.label.replace('-','')[:8],element=el,xyz=list(a.fract),occ=a.occ,biso=bi))
 return out

def model(path,name):
 s=get_model(path)
 return dict(name=name,sg=s.spacegroup.xhm(),cell=list(s.cell.parameters),atoms=atoms(s),source=path.name)

mods={}
mods['Fe2O3_Fe3O4_2ph']=[model(SOURCE/'cod_9000139.cif','Hematite'),model(SOURCE/'cod_9005837.cif','Magnetite')]
mods['Fe2O3_Fe3O4_2ph'][1]['cell']=[8.396,8.396,8.396,90,90,90]
mods['Fluoroapatite']=[model(SOURCE/'cod_9001232.cif','Fluorapatite')]
mods['LayeredOxide']=[model(SOURCE/'cod_4002260.cif','P2_NaNiMnMoO2'),model(SOURCE/'cod_2240655.cif','Na2MoO4')]
p2=mods['LayeredOxide'][0]
for a in p2['atoms']:
 if a['label']=='Na1':a['occ']=0.72*0.23/0.58
 if a['label']=='Na2':a['occ']=0.72*0.35/0.58;a['xyz']=[2/3,1/3,0.25]
 if a['element']=='Mn':a['occ']=0.62
 if a['element']=='Ni':a['occ']=0.33
 if a['element']=='O':a['occ']=1;a['xyz']=[2/3,1/3,0.094]
p2['atoms'].append(dict(label='Mo1',element='Mo',xyz=[0,0,0],occ=0.05,biso=0.5))
lfp=model(SOURCE/'cod_1101111.cif','LiFePO4_antisite_start1pct')
fe=next(a for a in lfp['atoms'] if a['element']=='Fe');li=next(a for a in lfp['atoms'] if a['element']=='Li')
fe['occ']=li['occ']=0.99
lfp['atoms'] += [dict(label='FeLi',element='Fe',xyz=li['xyz'][:],occ=0.01,biso=0.5),dict(label='LiFe',element='Li',xyz=fe['xyz'][:],occ=0.01,biso=0.5)]
mods['LiFePO4']=[lfp]
fe50=model(RAW/'FE50/CIF/candidate_A.cif','Cubic_K_FeMn_hexacyanoferrate')
fe50['atoms']=[dict(label='K1',element='K',xyz=[.25,.25,.25],occ=.73,biso=.5),dict(label='FeC',element='Fe',xyz=[0,0,0],occ=.97,biso=.5),dict(label='FeN',element='Fe',xyz=[.5,.5,.5],occ=.5,biso=.5),dict(label='MnN',element='Mn',xyz=[.5,.5,.5],occ=.5,biso=.5),dict(label='C1',element='C',xyz=[.185,0,0],occ=.97,biso=.5),dict(label='N1',element='N',xyz=[.3,0,0],occ=.97,biso=.5)]
mods['FE50']=[fe50]
mods['Amorphous']=[dict(name='Graphite_proxy_only',sg='P 63/m m c',cell=[2.46,2.46,6.71,90,90,120],source='constructed_standard_graphite_proxy',atoms=[dict(label='C1',element='C',xyz=[0,0,.25],occ=1,biso=.5),dict(label='C2',element='C',xyz=[1/3,2/3,.25],occ=1,biso=.5)])]

def multiplicity(sg,xyz):
 points=[]
 for op in sg.operations():
  pos=np.mod(op.apply_to_xyz(xyz),1)
  if not any(np.max(np.abs((pos-q+.5)%1-.5))<1e-4 for q in points):points.append(pos)
 return len(points)

def write_cif(m,p):
 sg=gemmi.find_spacegroup_by_name(m['sg']);d=gemmi.cif.Document();b=d.add_new_block(m['name'])
 for k,v in zip(['a','b','c','alpha','beta','gamma'],m['cell']):b.set_pair('_cell_'+('length_' if k in ['a','b','c'] else 'angle_')+k,str(v))
 b.set_pair('_space_group_name_H-M_alt',gemmi.cif.quote(sg.xhm()))
 b.set_pair('_space_group_IT_number',str(sg.number))
 b.set_pair('_audit_creation_method',gemmi.cif.quote('Prepared before the only AutoFP E2E; see inputs.json for source and adaptations'))
 l=b.init_loop('_space_group_symop_',['operation_xyz'])
 for op in sg.operations():l.add_row([gemmi.cif.quote(op.triplet())])
 l=b.init_loop('_atom_site_',['label','type_symbol','fract_x','fract_y','fract_z','occupancy','B_iso_or_equiv'])
 for a in m['atoms']:l.add_row([a['label'],a['element']]+[f'{x:.9f}' for x in a['xyz']]+[str(a['occ']),str(a['biso'])])
 d.write_file(str(p))

def pcr_block(m,j):
 sg=gemmi.find_spacegroup_by_name(m['sg']);general=len(sg.operations())
 # FullProf standard origin choices: Fd-3m origin 2, rhombohedral hexagonal axes.
 symbol=sg.hm
 mass=sum(a['occ']*multiplicity(sg,a['xyz'])*gemmi.Element(a['element']).weight for a in m['atoms'])
 lines=[f'! Phase {j}: {m["name"]}',m['name'],'! Nat Dis Ang Jbt Isy Str Furth ATZ Nvk More',f'{len(m["atoms"])} 0 0 0 0 0 0 {mass:.6f} 0 0','! Contributions','1','! Irf Npr Jtyp Nsp_Ref Ph_Shift','0 7 0 0 0','! Pr1 Pr2 Pr3 Brind Rmua Rmub Rmuc','0 0 1 1 1 1 1',symbol+'  <--Space group symbol','! Atom Typ X Y Z Biso Occ In Fin N_t Spc']
 for a in m['atoms']:
  a['multiplicity']=multiplicity(sg,a['xyz']);a['pcr_occ']=a['occ']*a['multiplicity']/general
  lines.append(f'{a["label"]:<8} {a["element"]:<4} '+ ' '.join(f'{x:.8f}' for x in a['xyz'])+f' {a["biso"]:.6f} {a["pcr_occ"]:.8f} 0 0 0 0')
  lines.append('0 0 0 0 0')
 w=4.0 if m['name']=='Graphite_proxy_only' else .01
 lines+=['! Scale Shape1 Bov Str1 Str2 Str3 Strain-Model','0.001 0 0 0 0 0 0',f'{j*10+1} 0 0 0 0 0','! U V W X Y GauSiz LorSiz Size-Model',f'0.01 -0.01 {w} 0 0 0 0 0','0 0 0 0 0 0 0','! a b c alpha beta gamma',' '.join(f'{x:.8f}' for x in m['cell']),'0 0 0 0 0 0','! Pref1 Pref2 Asy1 Asy2 Asy3 Asy4 S_L D_L','1 0 0 0 0 0 0 0','0 0 0 0 0 0 0 0']
 return lines
manifest=[]
for name in SAMPLES:
 d=BASE/'samples'/name; inp=d/'input';job=d/'run';inp.mkdir(parents=True,exist_ok=True);job.mkdir(exist_ok=True)
 if name=='LiFePO4':
  b=(RAW/name/'pattern.raw').read_bytes();assert b[:2]==b'FI' and b[24:26]==b'BU'
  l1,l2,l3=struct.unpack_from('<3d',b,1212);start,end,step=struct.unpack_from('<3f',b,2962);n=struct.unpack_from('<i',b,3154)[0]
  assert 3158+4*n==len(b)
  y=np.frombuffer(b,dtype='<f4',count=n,offset=3158).astype(float);x=np.linspace(start,end,n);data=np.c_[x,y]
  ratio=.5;decode='Profex 5.7.2 RigakuRawImport::loadNew offsets; little endian; exact byte count verified; native stored intensities'
 else:
  rows=[]
  for line in (RAW/name/'pattern_2theta.txt').read_text(errors='replace').splitlines():
   try:
    r=[float(v) for v in line.replace(',',' ').split()]
    if len(r)==2:rows.append(r)
   except ValueError:pass
  data=np.array(rows);l1,l2,ratio=(1.5405,1.5443,.5) if name=='Fluoroapatite' else (1.5406,1.54439,.5);decode='ASCII numeric rows only; original angles and intensities retained'
 assert np.all(np.diff(data[:,0])>0) and np.isfinite(data).all()
 np.savetxt(inp/'pattern.dat',data,fmt='%.12g')
 start,end=data[0,0],data[-1,0];step=float((end-start)/(len(data)-1))
 bg=float(np.percentile(data[:,1],20));cthm=.7 if name=='Fluoroapatite' else .91
 lines=['COMM '+name,'NPATT 1 1','W_PAT 1','! Nph Dum Ias Nre Cry Opt Aut',f'{len(mods[name])} 0 0 0 0 0 1','! Job Npr Nba Nex Nsc Nor Iwg Ilo Res Ste Uni Cor Anm Int','0 7 0 0 0 1 0 0 0 0 0 0 0 0','! Data file','pattern.dat','! Mat Pcr NLI Rpa Sym Sho','0 1 0 0 0 0','! Ipr Ppl Ioc Ls1 Ls2 Ls3 Prf Ins Hkl Fou Ana','0 0 1 0 4 0 3 10 0 0 0','! Lambda1 Lambda2 Ratio Bkpos Wdt Cthm muR AsyLim Rpolarz 2ndmuR',f'{l1:.8f} {l2:.8f} {ratio} 40 8 {cthm} 0 60 0 0','! NCY Eps R_at R_an R_pr R_gl','10 .1 1 1 1 1','! Thmin Step Thmax PSD Sent0',f'{start:.10f} {step:.10f} {end:.10f} 0 0',f'{len(mods[name])} ! Number of refined parameters','! Zero Code SyCos Code SySin Code Lambda Code MORE','0 0 0 0 0 0 0 0 0','! Background coefficients and codes',f'{bg} 0 0 0 0 0','0 0 0 0 0 0']
 for j,m in enumerate(mods[name],1):
  write_cif(m,inp/(m['name']+'.cif'));lines+=pcr_block(m,j)
 lines+=['! Plot interval',f'{start:.10f} {end:.10f} 1']
 (inp/'job.pcr').write_text('\n'.join(lines)+'\n')
 for f in inp.glob('*'):shutil.copyfile(f,job/f.name)
 item=dict(sample=name,points=len(data),range=[start,end],step=step,lambda1=l1,lambda2=l2,ratio=ratio,decode=decode,models=mods[name],initial_background=bg,mode='expert system -c 0 -a',attempts_allowed=1)
 (inp/'inputs.json').write_text(json.dumps(item,indent=2,ensure_ascii=False));manifest.append(item)
(BASE/'inputs_manifest.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False))
print(json.dumps([{'sample':x['sample'],'models':[m['name'] for m in x['models']],'points':x['points']} for x in manifest],indent=2))
