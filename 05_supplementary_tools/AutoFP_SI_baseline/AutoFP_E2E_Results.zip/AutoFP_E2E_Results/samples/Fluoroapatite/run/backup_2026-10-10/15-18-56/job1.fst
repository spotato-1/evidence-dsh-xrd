!   FILE for FullProf Studio: generated automatically by FullProf 
!Title: Fluorapatite                                                                                                                                                        
SPACEG P 63/m              
CELL     9.397300    9.397300    6.878200  90.0000  90.0000 120.0000   DISPLAY MULTIPLE
BOX   -0.15  1.15   -0.15  1.15    -0.15  1.15 
ATOM Ca1     Ca       0.66667   0.33333   0.00100  
ATOM Ca2     Ca      -0.00712   0.24227   0.25000  
ATOM P       P        0.36895   0.39850   0.25000  
ATOM O1      O        0.48490   0.32730   0.25000  
ATOM O2      O        0.46670   0.58750   0.25000  
ATOM O3      O        0.25750   0.34210   0.07050  
ATOM F       F        0.00000   0.00000   0.25000  
