!   FILE for FullProf Studio: generated automatically by FullProf 
!Title: Hematite                                                                                                                                                            
SPACEG R -3 c              
CELL     5.037441    5.037441   13.756261  90.0000  90.0000 120.0000   DISPLAY MULTIPLE
BOX   -0.15  1.15   -0.15  1.15    -0.15  1.15 
ATOM Fe      Fe       0.00000   0.00000   0.35504  
ATOM O       O        0.31424   0.00000   0.25000  
