## Fe2O3_Fe3O4_2ph

本样品正式调用次数为 1，状态 `exited`，退出码 0，用时 0 分 40.7 秒。AutoFP 原生 Rwp 从 94.80% 变为 25.90%；冻结 PRF 全谱 Rwp 为 1.542%，PRF χ² 为 2.9847。

初始结构来源与适配：COD 9000139，Blake et al., American Mineralogist 51 (1966) 123–129；COD 9005837，Nakagiri et al., Physics and Chemistry of Minerals 13 (1986) 238–244，DOI 10.1007/BF00308275。后者为 0.63 GPa 结构，原子拓扑沿用，初始晶格改为常温近似 a=8.396 Å。

两相谱形在全谱强度口径下贴合较好，但赤铁矿 Fe 的有效 Biso+Bov 为负，氧位占位超过 1；磁铁矿也有超满占位。由最终 PCR 比例因子、ATZ 和晶胞体积计算的质量比例仅是该非物理模型的参数结果，不能作为可靠定量物相分析。该例直接说明：高背景样品的全谱低 Rwp 与扣背景 Rwp、结构可信度可以给出很不相同的判断。

| 相 | 晶格参数 a b c / Å | Bov / Å² | 最低有效 Biso+Bov / Å² | 比例因子 |
|---|---|---:|---:|---:|
| Hematite | 5.03738 / 5.03738 / 13.75622 | 22.6371 | -0.5753 | 0.0007542951 |
| Magnetite | 8.38952 / 8.38952 / 8.38952 | 16.9152 | 0.6021 | 0.0001457289 |

最终结构审查记录：

- phase1 negative raw Biso components (consider Bov gauge): Fe,O
- phase1 negative effective Biso+Bov: Fe=-0.5753
- phase1 occupancy outside [0,1]: Fe=1.001,O=1.244
- phase2 negative raw Biso components (consider Bov gauge): Fe1,Fe2,O
- phase2 occupancy outside [0,1]: Fe2=1.051,O=1.249

由最终 PCR 计算的模型质量比例为 63.08%, 36.92%。这些值继承最终占位/热参数的物理问题，不作有效定量相分数结论。

自动循环 3 次，日志中的参数尝试 249 次，已接受参数状态 183 项；回滚事件 66 次，奇异矩阵标记 7 次，PCR 转换错误 1 次，非有限数值错误标记 4 次。内部错误可由回滚恢复，不等于独立 E2E 失败次数。

轨迹中最低已接受原生 Rwp 为 25.90%；这是路径统计，没有用它替换最终 PCR 或再次精修。

末次 OUT 的 Ynet Rwp 与 CLI 最终总结一致；完整 OUT、PRF、PCR 和总结均保留。原生 PNG 图是否成功生成独立于数值拟合；CLI 的 EPS 导出出现缺少 backend_ps 的打包提示时，保留已有 PNG，不修改 CLI 包。

原生最终图如下，图中的 Rwp 标签采用 AutoFP 原生扣背景口径。

![Fe2O3_Fe3O4_2ph native fit](run/autofp_prf2fig_job.png)
